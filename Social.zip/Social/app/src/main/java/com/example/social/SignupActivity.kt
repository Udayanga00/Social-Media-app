package com.example.social

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.social.databinding.ActivitySignupBinding
import com.google.firebase.auth.FirebaseAuth
import android.util.Patterns;
import com.example.social.model.Usermodel
import com.example.social.util.UiUtil
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore


class SignupActivity : AppCompatActivity() {

    lateinit var binding: ActivitySignupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)

        binding.submitBtn.setOnClickListener {
            signup()
        }

        binding.goToLoginBtn.setOnClickListener{
            startActivity(Intent(this,LoginActivity::class.java))
            finish()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    fun setInProgress(inProgress: Boolean) {
        if (inProgress) {
            binding.progressBar.visibility = View.VISIBLE
            binding.submitBtn.visibility = View.GONE
        } else {
            binding.progressBar.visibility = View.GONE
            binding.submitBtn.visibility = View.VISIBLE
        }
    }

    private fun signup() {
        val email = binding.emailInput.text.toString()
        val password = binding.passwordInput.text.toString() // Corrected variable name
        val confirmPassword = binding.confirmPasswordInput.text.toString()

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.emailInput.setError("Please enter a valid email address.");
            return;
        }

        if (password.length < 6) {
            binding.passwordInput.setError("Password must be at least 6 characters long.")
            return
        }
        if (password != confirmPassword) {
            binding.confirmPasswordInput.setError("Password does not match.")
            return
        }

        // Consider using secure authentication methods from Firebase instead
        signupWithFirebase(email, password)
    }

    private fun signupWithFirebase(email: String, password: String) {
        setInProgress(true) // Assuming this indicates UI loading state

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task -> // Use addOnCompleteListener for both success and failure
                if (task.isSuccessful) {
                    val user = task.result?.user ?: return@addOnCompleteListener
                    val username = email.substringBefore("@")
                    val usermodel = Usermodel(user.uid, email, username)

                    Firebase.firestore.collection("users")
                        .document(user.uid)
                        .set(usermodel)
                        .addOnSuccessListener {
                            UiUtil.showToast(applicationContext, "Account Created Successfully!")
                            setInProgress(false)
                            startActivity(Intent(this, MainActivity::class.java))
                            finish()
                        }
                        .addOnFailureListener{
                            UiUtil.showToast(applicationContext,it.localizedMessage?:"Something went wrong")
                            setInProgress(false)
                        }
                } else {
                    // Handle signup failure (e.g., weak password, email already in use)
                    val exception = task.exception
                    UiUtil.showToast(
                        applicationContext,
                        "Signup Failed: ${exception?.localizedMessage ?: "An error occurred"}"
                    )
                    setInProgress(false)
                }
            }
    }

}
